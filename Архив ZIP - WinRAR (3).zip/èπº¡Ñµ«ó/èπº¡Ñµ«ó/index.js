var fs = require('fs')
const express = require('express')
const app = express()
var bodyParser = require('body-parser');

app.set('view engine', 'ejs')
app.set ('views','./templates')
app.use (express.static('public'))
app.use(bodyParser.json());

app.get('/', function (req, res) {
  res.render('index', {name: "Kuznetsov", id: 1337})
})
app.get('/sales_list', function (req, res) {
    res.render('catalog')
  })
  app.get('/authentification', function (req, res) {
    res.render('authentification')
  })
  app.get('/Wishlist', function (req, res) {
    res.render('Wishlist')
  })
  app.post('/add-to-wishlist', function(req, res) {
    var product = req.body;
    var line = (product.name || 'Неизвестно') + ',' + (product.price || 'Неизвестно') + ',' + (product.image || 'Неизвестно') + '\n'; // Теперь включаем ссылку на изображение

    fs.appendFile('public/wishlist.csv', line, function(err) {
        if (err) {
            console.error(err);
            res.status(500).send('Server error');
        } else {
            res.status(200).send('Предмет добавлен в корзину');
        }
    });
});

app.post('/buy-product', function(req, res) {
    var product = req.body;
    var line = (product.id || 'Неизвестно') + ',' + (product.name || 'Неизвестно') + ',' + (product.price || 'Неизвестно') + '\n'; // Используем id, name и price

    fs.appendFile('public/orders.csv', line, function(err) {
        if (err) {
            console.error(err);
            res.status(500).send('Server error');
        } else {
            fs.readFile('public/wishlist.csv', 'utf8', function(err, data) {
                if (err) {
                    console.error(err);
                    res.status(500).send('Server error');
                } else {
                    var lines = data.split('\n');
                    var updatedLines = lines.filter(function(line) {
                        var parts = line.split(',');
                        var id = parts[0];
                        return id !== product.id;
                    });
                    fs.writeFile('public/wishlist.csv', updatedLines.join('\n'), function(err) {
                        if (err) {
                            console.error(err);
                            res.status(500).send('Server error');
                        } else {
                            res.status(200).send('Product bought successfully');
                        }
                    });
                }
            });
        }
    });
});

let port=1337
app.listen(port,  () => {console.log (`Cервер запущен ${port}`)})